import dash
from dash import dcc  # dash core components
from dash import html # dash html components
from dash.dependencies import Input, Output
import tensorflow as tf
import keras


external_stylesheets = ['https://codepen.io/chriddyp/pen/bWLwgP.css']

app = dash.Dash(__name__, external_stylesheets=external_stylesheets)
server = app.server


# cargar archivo de disco
model = keras.models.load_model('models/red_iris.keras')


app.layout = html.Div(
    [
    html.H6("Ingrese las catacterísticas de la flor"),
    html.Div(["Sepal length: ",
              dcc.Dropdown(id='sepal-length', value='1', options=['1', '2', '3', '4', '5', '6'])]),
    html.Br(),
    html.Div(["Sepal width: ",
              dcc.Dropdown(id='sepal-width', value='2', options=['1', '2', '3', '4', '5', '6'])]),
    html.Br(),
    html.Div(["Petal length: ",
              dcc.Dropdown(id='petal-length', value='1', options=['1', '2', '3', '4', '5', '6'])]),
    html.Br(),
    html.Div(["Petal width: ",
              dcc.Dropdown(id='petal-width', value='2', options=['1', '2', '3', '4', '5', '6'])]),
    html.Br(),
    
    html.H6("Probabilidad de que el carro esté detrás de cada puerta:"),
    html.Br(),
    html.Div(["Setosa:", html.Div(id='output-p1')]),
    html.Div(["Versicolor:", html.Div(id='output-p2')]),
    html.Div(["Virginica:", html.Div(id='output-p3')]),
    ]
)


@app.callback(
    Output(component_id='output-p1', component_property='children'),
    Output(component_id='output-p2', component_property='children'),
    Output(component_id='output-p3', component_property='children'),
    [Input(component_id='sepal-length', component_property='value'), 
     Input(component_id='sepal-width', component_property='value'),
     Input(component_id='petal-length', component_property='value'), 
     Input(component_id='petal-width', component_property='value')]
)
def update_output_div(sepal_length, sepal_width, petal_length, petal_width ):
    x = [[float(sepal_length), float(sepal_width), float(petal_length), float(petal_width)]]
    print(x)
    # Check inputs are correct 
    ypred = model.predict(x)  
    print(ypred[0])

    return '{0:.2f}'.format(ypred[0][0]), '{0:.2f}'.format(ypred[0][1]), '{0:.2f}'.format(ypred[0][2])
    
    


if __name__ == '__main__':
    app.run_server(debug=True)
